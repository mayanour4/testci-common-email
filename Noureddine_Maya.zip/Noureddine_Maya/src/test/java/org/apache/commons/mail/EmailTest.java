package org.apache.commons.mail;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.Date;

import javax.mail.Session;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class EmailTest {

	private static final String[] TEST_EMAILS = { "ab@bc.com", "a.b@c.org",
			"abcdefghijklmnopqrst@abcdefghijklmnopqrst.com.bd" };

	private String[] testValidChars = { " ", "a", "A", "\uc5ec", "0123456789", "012345678901234567890", "\n" };
	/* Concrete Email Class for testing */
	private EmailConcrete email;

	@Before
	public void setUpEmailTest() throws Exception {
		email = new EmailConcrete();
	}

	@After
	public void tearDownEmailTest() throws Exception {

	}

	/* test addBcc(String email) function */
	@Test
	public void testAddBcc() throws Exception {
		email.addBcc(TEST_EMAILS);
		assertEquals(3, email.getBccAddresses().size());

	}

	/* testing adding one email */
	@Test
	public void testAddCc() throws Exception {
		email.addCc("ab@bc.com");
		assertEquals(1, email.getCcAddresses().size());
	}

	/* testing adding 1 header */
	@Test
	public void testAddHeader() throws Exception {
		email.addHeader("addheader1", "header1val");
		assertEquals(1, email.getHeaders().size());
	}

	/* testing that the empty header name throws an exception */
	@Test(expected = IllegalArgumentException.class)
	public void testAddHeaderEmpty() throws Exception {
		email.addHeader("", "validVal");
	}

	/* testing adding one email to Reply To */
	@Test
	public void testAddReplyTo() throws Exception {
		email.addReplyTo("ab@bc.com");
		assertEquals(1, email.getReplyToAddresses().size());
	}

	/* testing host name is correctly set */
	@Test
	public void testGetHostNameSet() {
		email.hostName = "hostname1.com";
		assertEquals("hostname1.com", email.getHostName());
	}

	/* testing host name returns null */
	@Test
	public void testGetHostNameNull() {
		email.setHostName(null);
		assertEquals(null, email.getHostName());
	}

	/* testing returns non null session when host name is set */
	@Test
	public void testGetMailSessionNonNull() throws EmailException {
		email.setHostName("12345678.test.com");
		Session session = email.getMailSession();
		assertNotNull(session);
	}

	/* testing throws email exception if host name is not set */
	@Test(expected = EmailException.class)
	public void testGetMailSessionNull() throws EmailException {
		email.setHostName(null);
		email.getMailSession();
	}

	/* testing returns new date and not null */
	@Test
	public void testGetSentDateNulll() {
		Date result = email.getSentDate();
		assertNotNull(result);
	}

	/* testing returning the correct date that was set */
	@Test
	public void testGetSentDateSet() {
		Date now = new Date();
		email.setSentDate(now);
		Date result = email.getSentDate();
		assertEquals(now.getTime(), result.getTime());
	}

	/* testing returns correct value */
	@Test
	public void testGetSocketConnectionTimeout() {
		email.setSocketConnectionTimeout(14);
		assertEquals(14, email.getSocketConnectionTimeout());
	}

	/* testing set the address and is not null */
	@Test
	public void testSetFrom() throws Exception {
		email.setFrom("1234567@example.com");
		assertNotNull(email.getFromAddress());
	}

	/* testing normal path, should not throw exception */
	@Test
	public void testBuildMimeMessageSuccess() throws Exception {
		email.setHostName("ab@bc.com");
		email.setFrom("from@1.com");
		email.addBcc("98765@1234.com");

		email.buildMimeMessage();
	}

}
