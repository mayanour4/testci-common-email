package org.apache.commons.mail;

import java.util.Date;
import java.util.Map;

public class EmailConcrete extends Email {

	@Override
	public Email setMsg(String msg) throws EmailException {
		return null;
	}

	public Map<String, String> getHeaders() {
		return this.headers;
	}

	public String getContentType() {
		return this.contentType;
	}

	public void setSentDate(Date date) {
	    this.sentDate = date;
	}
	
	public void setSocketConnectionTimeout(int timeout) {
	    this.socketConnectionTimeout = timeout;
	}
	
	public javax.mail.internet.InternetAddress getFromAddress() {
	    return this.fromAddress;
	}
}
